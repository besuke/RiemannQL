# Cross-currency curves and the yen asset swap on them. Synthetic inputs.

today <- "2026-11-04"
sofr <- create_flat_curve(today, 0.042, "actual_365_fixed", index = "sofr")
tonar <- create_flat_curve(today, 0.005, "actual_365_fixed", index = "tonar")

test_that("a cross-currency curve reprices its FX swaps and basis swaps", {
  quotes <- create_xccy_instruments(c("fx_swap", "fx_swap", "basis_swap", "basis_swap", "basis_swap"), c("3M", "6M", "2Y", "5Y", "10Y"),
                                    c(-1.62, -3.2, -0.0042, -0.0050, -0.0048))
  curve <- bootstrap_xccy_curve(today, sofr, tonar, base_is_collateral = FALSE, fx_spot = 150, instruments = quotes)
  expect_s3_class(curve, "rmql_ois_curve")
  expect_lt(max(abs(curve$repricing$implied_quote - curve$repricing$quote)), 1e-9)
  # a more negative basis on the yen leg lowers the yen leg's value, so at par the dollar leg is worth
  # less: the dollar discount rate under yen collateral rises
  deeper <- bootstrap_xccy_curve(today, sofr, tonar, FALSE, 150, create_xccy_instruments("basis_swap", "5Y", -0.0080))
  shallow <- bootstrap_xccy_curve(today, sofr, tonar, FALSE, 150, create_xccy_instruments("basis_swap", "5Y", -0.0020))
  expect_lt(compute_discount(deeper, as.Date("2031-11-04")), compute_discount(shallow, as.Date("2031-11-04")))
  mtm <- bootstrap_xccy_curve(today, sofr, tonar, FALSE, 150, create_xccy_instruments("basis_swap", c("2Y", "5Y"), c(-0.0042, -0.0050), resetting = "base"))
  expect_lt(max(abs(mtm$repricing$implied_quote - mtm$repricing$quote)), 1e-9)
  expect_error(bootstrap_xccy_curve(today, sofr, tonar, FALSE, 150, create_xccy_instruments("deposit", "1Y", 0.01)), "fx_swap or basis_swap")
  expect_error(bootstrap_xccy_curve(today, sofr, tonar, FALSE, -1, quotes), "positive")
})

test_that("the yen asset swap on a curve equal to the constant-z forward gives the constant-z result", {
  bond <- create_fixed_rate_bond(2L, 100, "2026-11-06", "2033-11-06", "6M", "us_government_bond", "unadjusted", "unadjusted", "backward", FALSE,
                                 0.04, "thirty_360_bond_basis", "following", 100)
  constant <- compute_yen_asset_swap(bond, 99.5, sofr, tonar, fx_spot = 150, basis_bp = -45, evaluation_date = today)
  shifted <- create_zero_spreaded_curve(sofr, constant$calibrated_discount_spread_bp / 1e4)
  on_curve <- compute_yen_asset_swap_on_basis_curve(bond, 99.5, sofr, tonar, shifted, fx_spot = 150, evaluation_date = today)
  expect_equal(on_curve$yen_asw_bp, constant$yen_asw_bp, tolerance = 1e-10)
  expect_equal(on_curve$native_asw_bp, constant$native_asw_bp, tolerance = 1e-12)
  # on a bootstrapped basis curve the yen spread moves with the basis, about one for one
  curve_of <- \(basis) bootstrap_xccy_curve(today, sofr, tonar, FALSE, 150, create_xccy_instruments("basis_swap", c("2Y", "7Y"), basis))
  moves <- purrr::map_dbl(list(c(-0.0040, -0.0045), c(-0.0050, -0.0055)), \(b) {
    compute_yen_asset_swap_on_basis_curve(bond, 99.5, sofr, tonar, curve_of(b), 150, today)$yen_asw_bp
  })
  expect_equal(moves[1] - moves[2], 10, tolerance = 0.05)
})

test_that("the time value of the collateral choice", {
  today <- "2026-11-04"
  yen <- create_zero_curve(as.Date(today) + c(0, 365, 3652), c(0.005, 0.005, 0.012), "actual_365_fixed")
  usd <- create_zero_curve(as.Date(today) + c(0, 365, 3652), c(0.009, 0.009, 0.006), "actual_365_fixed")
  dates <- as.Date(today) + c(365, 1826, 3652)
  still <- compute_ctd_time_value(today, dates, list(JPY = yen, USD = usd), volatility = 0, paths = 10L)
  intrinsic <- create_ctd_curve(today, dates[3], list(JPY = yen, USD = usd))
  expect_equal(still$value, compute_discount(intrinsic, dates), tolerance = 1e-12)
  r <- compute_ctd_time_value(today, dates, list(JPY = yen, USD = usd), volatility = 0.005, mean_reversion = 0.1, paths = 1000L)
  expect_true(all(abs(log(r$first_order) - log(r$first_order_formula)) < 4 * r$log_standard_error))
  expect_true(all(r$value >= r$first_order))
  expect_gt(r$time_value[3], 4 * r$standard_error[3])
  expect_error(compute_ctd_time_value(today, dates, list(JPY = yen, USD = usd), volatility = c(0.1, 0.1)))
})

test_that("the time value of the collateral choice does not depend on the number of threads", {
  today <- "2026-11-04"
  yen <- create_zero_curve(as.Date(today) + c(0, 365, 3652), c(0.005, 0.005, 0.012), "actual_365_fixed")
  usd <- create_zero_curve(as.Date(today) + c(0, 365, 3652), c(0.009, 0.009, 0.006), "actual_365_fixed")
  dates <- as.Date(today) + c(365, 1826, 3652)
  run <- function(threads) compute_ctd_time_value(today, dates, list(JPY = yen, USD = usd), volatility = 0.005, mean_reversion = 0.1,
                                                  paths = 1500L, seed = 3, threads = threads)
  one <- run(1L)
  for (threads in c(2L, 4L, 0L)) expect_identical(run(threads), one, info = as.character(threads))
  expect_error(run(-1L), "threads")
})
